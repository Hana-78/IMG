#include <opencv.hpp>
#include <iostream>
#include "ImageAlignment.hpp"

using namespace cv;
using namespace std;

enum ArgIndex{
	inputOrignalImagePath = 1,
	inputStitchingImagePath = 2,
	outputImagePath = 3,
	ArgMax = 4,
};

int main(int argc, char **argv)
{
#if _DEBUG
	argc = ArgMax;
	argv[inputOrignalImagePath] = "D:/00_PROJECT/2018-03-15_Image_Alignment_and_Sititching/reference/image/4.jpg";
	argv[inputStitchingImagePath] = "D:/00_PROJECT/2018-03-15_Image_Alignment_and_Sititching/reference/image/5.jpg";
	argv[outputImagePath] = "D:/00_PROJECT/2018-03-15_Image_Alignment_and_Sititching/reference/image/test.jpg";
#endif

	char inputOrignalimage[128] = { 0 };
	char inputStitchingimage[128] = { 0 };
	char outputimage[128] = { 0 };

	sscanf(argv[inputOrignalImagePath], "%s", inputOrignalimage);
	sscanf(argv[inputStitchingImagePath], "%s", inputStitchingimage);
	sscanf(argv[outputImagePath], "%s", outputimage);

	if (4 == argc)
	{
		ImageAlignment(inputOrignalimage, inputStitchingimage, outputimage);
		cout << "Success !" << endl;

	}

	return 0;
}