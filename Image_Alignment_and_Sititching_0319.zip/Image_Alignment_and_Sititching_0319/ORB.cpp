#include <iostream>
#include <opencv.hpp>

#include "ORB.hpp"

using namespace cv;
using namespace std;

void FeatureMatches(Mat &inputImage_left, Mat &inputImage_right, vector<Point2f>& FeaturePoints_left, vector<Point2f>& FeaturePoints_right)
{
	//detect Feature
	//double t = getTickCount();
	OrbFeatureDetector featureDetector(3000);
	vector<KeyPoint> keyPoint_left, keyPoint_right;
	featureDetector.detect(inputImage_left, keyPoint_left);
	featureDetector.detect(inputImage_right, keyPoint_right);

	//Feature Extraction
	OrbDescriptorExtractor featureDescriptor;
	Mat descriptors_left, descriptors_right;
	featureDescriptor.compute(inputImage_left, keyPoint_left, descriptors_left);
	featureDescriptor.compute(inputImage_right, keyPoint_right, descriptors_right);

	//Match based on FLANN descriptor
	flann::Index flannIndex(descriptors_right, flann::LshIndexParams(12, 20, 2), cvflann::FLANN_DIST_HAMMING);

	vector<DMatch> goodMatches;

	Mat matchIndex(descriptors_left.rows, 2, CV_32SC1), matchDistance(descriptors_left.rows, 2, CV_32FC1);
	flannIndex.knnSearch(descriptors_left, matchIndex, matchDistance, 2, flann::SearchParams());
	
	//Lowe's algorithm
	for (int i = 0; i < matchDistance.rows; i++){
		if (matchDistance.at<float>(i, 0) < 0.4*matchDistance.at<float>(i, 1)){
			DMatch dmatches(i, matchIndex.at<int>(i, 0), matchDistance.at<float>(i, 0));
			goodMatches.push_back(dmatches);
		}
	}

	for (int i = 0; i < goodMatches.size(); i++)
	{
		FeaturePoints_left.push_back(keyPoint_left[goodMatches[i].queryIdx].pt);
		FeaturePoints_right.push_back(keyPoint_right[goodMatches[i].trainIdx].pt);
	}

}
