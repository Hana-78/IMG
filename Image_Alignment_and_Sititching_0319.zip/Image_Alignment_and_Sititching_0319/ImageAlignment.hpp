#ifndef IMAGEALIGNMENT_HPP_
#define IMAGEALIGNMENT_HPP_

#include <iostream>
#include <opencv.hpp>

#include "ORB.hpp"
#include "PerspectiveTransformations.hpp"

using namespace std;
using namespace cv;

int ImageAlignment(char* OrigImg, char* StitchImg, char* outputImg);

#endif