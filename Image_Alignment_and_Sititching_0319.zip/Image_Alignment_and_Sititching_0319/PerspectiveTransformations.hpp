#ifndef PERSPECTIVETRANSFORMATIONS_HPP_
#define PERSPECTIVETRANSFORMATIONS_HPP_

#include <iostream>
#include <opencv.hpp>

#include "ImageAlignment.hpp"
#include "ORB.hpp"

using namespace std;
using namespace cv;

typedef struct
{
	Point2f leftup;
	Point2f leftdown;
	Point2f rightup;
	Point2f rightdown;
}four_corners;

void Transformations(Mat &rgbinputImage_left, Mat &rgbinputImage_right, vector<Point2f>& FeaturePoints_left, vector<Point2f>& FeaturePoints_right, char* outputimage);

#endif