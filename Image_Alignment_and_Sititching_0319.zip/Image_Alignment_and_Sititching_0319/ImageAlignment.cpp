#include <opencv.hpp>
#include <iostream>

#include "ImageAlignment.hpp"

using namespace cv;
using namespace std;

int ImageAlignment(char* OrigImage, char* StitchImg, char* outputImg)
{
	Mat rgbOrigImg, rgbStitchImg, grayOrigImg, grayStitchImg;

	rgbOrigImg = imread(OrigImage);
	rgbStitchImg = imread(StitchImg);

	if (rgbOrigImg.empty() || rgbStitchImg.empty()){
		cout << "Could not open the image" << endl;
		return -1;
	}

	cvtColor(rgbOrigImg, grayOrigImg, CV_BGR2GRAY);
	cvtColor(rgbStitchImg, grayStitchImg, CV_BGR2GRAY);

	vector<Point2f> OrigImgFeature, StitchImgFeature;
	
	FeatureMatches(grayinputImage_left, grayinputImage_right, FeaturePoints_left, FeaturePoints_right);
	Transformations(rgbinputImage_left, rgbinputImage_right, FeaturePoints_left, FeaturePoints_right, outputimage);

	return 0;
}

