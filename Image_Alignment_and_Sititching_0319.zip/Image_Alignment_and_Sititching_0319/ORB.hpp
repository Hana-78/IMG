#ifndef ORB_HPP_
#define ORB_HPP_

#include <iostream>
#include <opencv.hpp>

#include "ImageAlignment.hpp"

using namespace std;
using namespace cv;

void FeatureMatches(Mat &inputImage_left, Mat &inputImage_right, vector<Point2f>& FeaturePoints_left, vector<Point2f>& FeaturePoints_right);

#endif