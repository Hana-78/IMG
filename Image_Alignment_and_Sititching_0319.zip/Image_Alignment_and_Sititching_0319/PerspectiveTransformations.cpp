#include <iostream>
#include <opencv.hpp>

#include "PerspectiveTransformations.hpp"

using namespace cv;
using namespace std;

four_corners corners;

void ImageRight2Left(const Mat& H, const Mat& src)
{
	double v2[] = { 0, 0, 1 };
	double v[3];
	Mat V2 = Mat(3, 1, CV_64FC1, v2);
	Mat V1 = Mat(3, 1, CV_64FC1, v);

	//leftup corner = (0,0,1)
	V1 = H * V2;
	corners.leftup.x = v[0] / v[2];
	corners.leftup.y = v[1] / v[2];

	//leftdown corner = (0,src.rows,1)
	v2[0] = 0;
	v2[1] = src.rows;
	v2[2] = 1;
	V2 = Mat(3, 1, CV_64FC1, v2);
	V1 = Mat(3, 1, CV_64FC1, v);
	V1 = H * V2;
	corners.leftdown.x = v[0] / v[2];
	corners.leftdown.y = v[1] / v[2];

	//rightup corner = (src.cols,0,1)
	v2[0] = src.cols;
	v2[1] = 0;
	v2[2] = 1;
	V2 = Mat(3, 1, CV_64FC1, v2);
	V1 = Mat(3, 1, CV_64FC1, v);
	V1 = H * V2;
	corners.rightup.x = v[0] / v[2];
	corners.rightup.y = v[1] / v[2];

	//rightdown corner = (src.cols,src.rows,1)
	v2[0] = src.cols;
	v2[1] = src.rows;
	v2[2] = 1;
	V2 = Mat(3, 1, CV_64FC1, v2);
	V1 = Mat(3, 1, CV_64FC1, v);
	V1 = H * V2;
	corners.rightdown.x = v[0] / v[2];
	corners.rightdown.y = v[1] / v[2];

}

void OptimizeSeam(Mat& img_l, Mat& trans, Mat& ImageTransform)
{
	int overlap_l = MIN(corners.leftup.x, corners.leftdown.x);

	int overlap_Width = img_l.cols - overlap_l;
	double alpha = 1;

	for (int i = 0; i < ImageTransform.rows; i++){
		uchar* p = img_l.ptr<uchar>(i);
		uchar* t = trans.ptr<uchar>(i);
		uchar* d = ImageTransform.ptr<uchar>(i);

		for (int j = 0; j < img_l.cols; j++){
			if (t[j * 3] == 0 && t[j * 3 + 1] == 0 && t[j * 3 + 2] == 0){
				alpha = 1;
			}
			else{
				alpha = (overlap_Width - (j - overlap_l)) / overlap_Width;
			}

			d[j * 3] = p[j * 3] * alpha + t[j * 3] * (1 - alpha);
			d[j * 3 + 1] = p[j * 3 + 1] * alpha + t[j * 3 + 1] * (1 - alpha);
			d[j * 3 + 2] = p[j * 3 + 2] * alpha + t[j * 3 + 2] * (1 - alpha);
		}
	}
}

void Transformations(Mat &rgbinputImage_left, Mat &rgbinputImage_right, vector<Point2f>& FeaturePoints_left, vector<Point2f>& FeaturePoints_right, char* outputimage)
{
	Mat Homo = findHomography(FeaturePoints_right, FeaturePoints_left, CV_RANSAC);
	cout << "�任����Ϊ:\n" << Homo << endl << endl;

	ImageRight2Left(Homo, rgbinputImage_right);

	Mat ImageTransform_R;
	warpPerspective(rgbinputImage_right, ImageTransform_R, Homo, Size(MAX(corners.rightup.x, corners.rightdown.x), rgbinputImage_left.rows));

	int ImageTransform_cols = ImageTransform_R.cols;
	int ImageTransform_rows = rgbinputImage_left.rows;

	Mat ImageTransform(ImageTransform_rows,ImageTransform_cols, CV_8UC3);
	ImageTransform.setTo(0);

	ImageTransform_R.copyTo(ImageTransform(Rect(0, 0, ImageTransform_R.cols, ImageTransform_R.rows)));
	rgbinputImage_left.copyTo(ImageTransform(Rect(0, 0, rgbinputImage_left.cols, rgbinputImage_left.rows)));

	OptimizeSeam(rgbinputImage_left, ImageTransform_R, ImageTransform);

	imwrite(outputimage, ImageTransform);
	waitKey();
}
